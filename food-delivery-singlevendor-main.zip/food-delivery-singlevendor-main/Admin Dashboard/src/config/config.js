/* eslint-disable camelcase */
export const server_url = process.env.REACT_APP_SERVER_URL
export const ws_server_url = process.env.REACT_APP_WS_SERVER_URL
export const cloudinary_upload_url = process.env.REACT_APP_CLOUDINARY_UPLOAD_URL
export const cloudinary_category = process.env.REACT_APP_CLOUDINARY_CATEGORY
export const cloudinary_food = process.env.REACT_APP_CLOUDINARY_FOOD
