import TextDefault from './TextDefault/TextDefault'
import TextError from './TextError/TextError'
import TextLine from './TextLine/TextLine'

export { TextDefault, TextError, TextLine }
