export default {
  logo_image: {
    height: '17%',
    width: '55%',
    alignSelf: 'center',
    marginBottom: '50%'
  }
}
